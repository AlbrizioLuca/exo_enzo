#!/bin/bash
    # Consigne:	Ecrire en bash un script qui prend en entrée un nombre entier et renvoie « true » si c'est un nombre premier,  « false » sinon.

    # Afficher un message pour que l'utilisateur saisisse un nombre entier autre que 1
      # Définir la variable dans laquelle on va stocker l'input
read -p "Veuillez saisir un nombre entier >1, afin de savoir s'il s'agit d'un nombre premier : " nombre
    # Initialiser un compteur à 2, celui ci servira de diviseur, afin de savoir si un diviseur autre que 1 ou le nombre lui meme existe
i=2
    # Boucler jusqu'à la moitié, car si le diviseur=nombre/2 cela signifie qu'il est divisible par 2 et donc n'est pas un nombre premier
while [ $i -lt $(($nombre / 2)) ]; do
      # Vérifier pour chaque diviseur i si le reste de la division =0, si oui cela veut dire que le nombre est divisible par un nombre autre que 1 ou lui meme et donc il n'est pas premier 
  if [ $(($nombre % $i)) == 0 ]; then
#   Afficher message FALSE
    echo "FALSE - Ce nombre possède au moins 3 diviseurs. "
    exit
  fi
      # Incrémenter le compteur pour réitérer la boucle 
  i=$(($i + 1))
done
    # Afficher message TRUE car aucun diviseur autre que lui meme et 1, alors c'est un nombre premier
echo "TRUE - Ce nombre est premier car il possède UNIQUEMENT deux diviseurs: 1 et lui-même."