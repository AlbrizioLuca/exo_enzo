#!/bin/bash
        # Consigne: Ecrire en bash un script qui prend en entrée un nombre entier et renvoie le nombre de chiffres de ce nombre.

        # Afficher un message pour que l'utilisateur saisisse un nombre entier
            # Définir la variable dans laquelle on va stocker l'input
read -p "Entrez un nombre entier : " nombre

        # Definir une variable pour calculer la longueur de la chaîne de caractères
            # Utilisation de la commande `expr length` qui va calculer le nombre de caractères dans la variable associée
nb_chiffre=`expr length $nombre`

echo "Le nombre de chiffres de $nombre est $nb_chiffre"