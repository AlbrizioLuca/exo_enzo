#!/bin/bash
clear
    #Consigne: Ecrire en bash un script qui prend en entrée un nombre entier et affiche tous les nombres de 1 à ce nombre.

    # Afficher un message pour que l'utilisateur saisisse un nombre entier
      # Définir la variable dans laquelle on va stocker l'input
read -p "Veuillez saisir un nombre entier: " nombre
    # On fait une boucle qui va permettre d'afficher les nombres de 1 au numero correspondant à la valeur de num
for i in $(seq 1 $nombre); do
  echo $i
done