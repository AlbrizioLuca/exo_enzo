#!/bin/bash
clear
    # Afficher un message pour que l'utilisateur saisisse un texte entre guillemets
      # Définir la variable dans laquelle on va stocker l'input
read -p "Veuillez saisir votre texte entre guillemets: " texte
    # Créer une variable afin de compter le nombre de voyelles, et on remet à zéro son compteur
compte_voyelle=0
    # Créer une boucle qui parcourt chaque caractère de la chaîne
for ((i=0; i<${#texte}; i++)); do
      # Vérifier si le caractère est une voyelle en se referant au tableau
      # Définir tous les caractères que ce soit minuscule ou majuscule, mais aussi avec accents 
  if [[ "${texte:$i:1}" == [AaàEeéèêIiOoUuùYy] ]]; then
        # si oui, incrémenter le compteur
    ((compte_voyelle++))
  fi 
done
    # Afficher enfin le résultat obtenu
echo -e "Le nombre de voyelles dans le texte" "\n$texte" "\nest : $compte_voyelle"