#!/bin/bash
        # Consigne: Ecrire en bash un script qui prend en entrée deux chaînes de caractères et renvoie « true » si elles sont des anagrammes, « false » sinon
clear
        # Afficher un message pour que l'utilisateur saisisse deux mots
            # Définir la variable dans laquelle on va stocker l'input
read -p "Veuillez saisir le premier mot: " mot1
read -p "Veuillez saisir le deuxième mot: " mot2
        # Définir la condition dans laquelle on compare les deux chaines, en utisant les commandes
            # "grep -o" pour dissocier chaque caractère
                # "sort" pour les trier, et "tr -d '\n'" pour supprimer les retours à la ligne qu'à crée la commande sort
                    # on compare les deux chaines si elles sont strictement égales ou non
if [ $(echo $mot1 | grep -o . | sort | tr -d '\n') == $(echo $mot2 | grep -o . | sort | tr -d '\n') ]
then
        # si oui afficher le message qu'il s'agit pas d'anagramme'
    echo "TRUE - Ces deux termes sont des anagrammes"
else
        # sinon afficher message d'erreur
    echo "FALSE - Ces deux termes ne sont pas des anagrammes"
fi