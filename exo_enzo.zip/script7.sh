#!/bin/bash
    # Consigne: Ecrire en bash un script qui prend en entrée un nombre entier et renvoie la somme des chiffres de ce nombre.
clear
    # Afficher un message pour que l'utilisateur saisisse un nombre entier
    # Définir la variable dans laquelle on va stocker l'input
read -p "Entrez un nombre entier : " nombre
    # Initialiser la variable à zéro, elle sera incrementée à chaque boucle 
somme=0
    # Réaliser une Boucle pour parcourir chaque chiffre de l'input
    #Séparer chaque chiffre de l'input afin de les traiter séparément 
for nb_chiffre in $(echo $nombre | grep -o .); do
      # Ajouter chaque chiffre séparément à la somme et additionne avec les chiffres précedents
  somme=$((somme + nb_chiffre))
done

    # Afficher la somme des chiffres du nombre saisi
echo -e "La somme des chiffres de : " $nombre "\nest égale à: $somme"