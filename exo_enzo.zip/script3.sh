#!/bin/bash
    # Consigne:	Ecrire un script qui prend en entrée un tableau d'entiers et renvoie le plus grand élément du tableau.
clear
    # Définir fonction pour chercher le plus grand nombre.
trouve_le_plus_grand() {
      # Définir deux variables pour récupérer les données
    #   Définir le premier nombre du tableau comme le plus grand
    local tableau=("$@")
    local plus_grand=${tableau[0]}
        # Crée une boucle qui va comparer le premier nombre avec le suivant
    for i in "${tableau[@]}"; do
        # Si le nombre suivant est plus grand alors il sera stocké dans la variable
        ((i > plus_grand)) && plus_grand=$i
    done
    echo $plus_grand
}
    # Donner une liste de nombres entiers comme données
liste_nombres=(81 33 74 65 42 96 27)
    # Appeler la fonction pour trouver le plus grand élément
le_plus_grand=$(trouve_le_plus_grand "${liste_nombres[@]}")
    # Afficher le résultat
echo "Le plus grand nombre est: $le_plus_grand"